"use client"

import contractABI from '../lib/contract.json';


import { getContractAddress } from 'ethers/lib/utils'

import { useState, useEffect } from 'react'

import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Github, Linkedin, Mail, Phone, Download, Wallet } from "lucide-react"
import Link from 'next/link'
import { ethers } from 'ethers'

export default function Portfolio() {
  const [activePage, setActivePage] = useState('about')
  const [walletAddress, setWalletAddress] = useState('')
  const [donationAmount, setDonationAmount] = useState('')

  const portfolioData = {
    name: "Ritik Kumar",
    title: "Computer Science Student & Blockchain Enthusiast",
    about: "I'm Ritik Kumar, a Computer Science and Engineering student at Vel Tech University with a passion for blockchain and web development. I'm skilled in various programming languages and have experience in developing decentralized applications and web-based systems.",
    education: [
      {
        school: "Vel Tech University, Chennai, India",
        degree: "Bachelor of Technology in Computer Science and Engineering",
        date: "Aug 2021 - June 2025",
        gpa: "GPA: 8.5/10"
      },
      {
        school: "BBN College Balepur, India",
        degree: "Intermediate Education (Science Stream)",
        date: "Mar 2018 - June 2020",
        gpa: "Percentage: 72%"
      }
    ],
    experiences: [
      {
        title: "Leadership Development",
        company: "Veltech University",
        date: "2024",
        description: "Led a team of 10+ in university projects, enhancing overall team performance by 15%."
      },
      {
        title: "Active Coding Club Member",
        company: "Veltech University",
        date: "2024",
        description: "Competed in coding challenges and collaborative projects, driving a 30% increase in team success rates."
      }
    ],
    projects: [
      {
        name: "Drive Bank 3.0",
        date: "Aug 2024 - Present",
        description: "Engineered a decentralized application (dApp) for secure digital data management.",
        link: "https://github.com/heyritikk/A-DRIVE-BANK-3.0" // GitHub link
      },
      {
        name: "Bank Management System",
        date: "Jul 2024 - Present",
        description: "Designed a bank management system that processed transactions with 99% accuracy.",
        link: "https://github.com/heyritikk/BANK-MANAGEMENT-SYSTEM" // GitHub link
      },
      {
        name: "Find My Pathasala",
        date: "Mar 2023 - Jun 2023",
        description: "Launched a web-based platform for 'Find My Pathasala'.",
        link: "https://github.com/heyritikk" // GitHub link
      }
    ],
    certificates: [
      {
        name: "Nanotechnology in Agriculture",
        issuer: "NPTEL",
        date: "2023",
        file: "https://ipfs.io/ipfs/QmTTrqJkvv2YrounKNFakZQarZzfyXspQMZY1Yi8Y2G2Dt", // Replace with your actual IPFS link
      },
      {
        name: "CCNA CISCO (Networking Certification)",
        issuer: "Cisco",
        date: "2023",
        file: "https://ipfs.io/ipfs/QmTTrqJkvv2YrounKNFakZQarZzfyXspQMZY1Yi8Y2G2Dt", // Replace with your actual IPFS link
      },
      {
        name: "Blockchain and Cryptocurrency Basics",
        issuer: "Udemy",
        date: "2024",
        file: "https://ipfs.io/QmTTrqJkvv2YrounKNFakZQarZzfyXspQMZY1Yi8Y2G2Dt", // Replace with your actual IPFS link
      }
    ],
    
  }




  
  useEffect(() => {
    checkIfWalletIsConnected();
  }, []);
  
 // Check if the wallet is connected
 const checkIfWalletIsConnected = async () => {
  try {
    const { ethereum }: any = window;

    if (!ethereum) {
      console.log("Make sure you have MetaMask installed!");
      return;
    }

    const accounts = await ethereum.request({ method: 'eth_accounts' });
    if (accounts.length !== 0) {
      const account = accounts[0];
      setWalletAddress(account);
      fetchProjectDetails(); // Fetch project details when wallet is connected
    } else {
      console.log("No authorized account found");
    }
  } catch (error) {
    console.error("Error checking if wallet is connected:", error);
  }
};

// Connect wallet function
const connectWallet = async () => {
  try {
    const { ethereum }: any = window;

    if (!ethereum) {
      alert("Please install MetaMask!");
      return;
    }

    const accounts = await ethereum.request({ method: 'eth_requestAccounts' });
    const account = accounts[0];
    setWalletAddress(account);
    fetchProjectDetails(); // Fetch project details after connecting
  } catch (error) {
    console.error("Error connecting wallet:", error);
  }
};

useEffect(() => {
  checkIfWalletIsConnected();
}, []);

const fetchProjectDetails = async () => {
  // Your logic to fetch project details goes here
  console.log("Fetching project details...");
};




  // Fetch project details


  
  




  
  // Donate Ether function
  const donateEther = async () => {
    try {
      const { ethereum } = window as any;
      if (!ethereum) {
        alert("Please install MetaMask!");
        return;
      }
  
      const provider = new ethers.providers.Web3Provider(ethereum);
      const signer = provider.getSigner();
  
      const tx = await signer.sendTransaction({
        to: "0x5C7078010eA1046720D08Daef080e1F75bB13682", // Replace with your actual Ethereum address
        value: ethers.utils.parseEther(donationAmount),
      });
  
      await tx.wait();
      alert("Thank you for your donation!");
  
      fetchProjectDetails(); // Fetch updated project details after donation
    } catch (error) {
      console.error(error);
      alert("An error occurred while processing your donation.");
    }
  };
  
  const downloadResume = () => {
    // Replace 'path_to_your_resume.pdf' with the actual path to your resume file
    const link = document.createElement('a')
    link.href = "https://ipfs.io/ipfs/QmS7p5cWrk5cha6vUnRLVrNjcRDubW1eqMPFWDxtAkDKEy",
    link.download = 'Ritik_Kumar_Resume.pdf'
    document.body.appendChild(link)
    link.click()
    document.body.removeChild(link)
  }
  

  const downloadCertificate = (ipfsLink: string) => {
    const link = document.createElement('a');
    link.href = ipfsLink; // Use the IPFS link for the certificate
    link.target = '_blank'; // Open in a new tab
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  }
  
  

  const renderContent = () => {
    switch (activePage) {
      case 'about':
        return <p className="text-gray-600">{portfolioData.about}</p>
      case 'resume':
        return (
          <div>
            <h2 className="text-2xl font-bold mb-4">Education</h2>
            {portfolioData.education.map((edu, index) => (
              <div key={index} className="mb-4">
                <h3 className="font-semibold">{edu.school}</h3>
                <p>{edu.degree}</p>
                <p>{edu.date}</p>
                <p>{edu.gpa}</p>
              </div>
            ))}
          </div>
        )

        case 'projects':
          return (
            <div>
              <h2 className="text-2xl font-bold mb-4">Projects</h2>
              {portfolioData.projects.map((project, index) => (
                <div key={index} className="mb-4">
                  <h3 className="font-semibold">
                    <Link href={project.link} target="_blank" className="text-blue-600 hover:underline">
                      {project.name}
                    </Link>
                  </h3>
                  <p>{project.date}</p>
                  <p>{project.description}</p>
                </div>
              ))}
            </div>
          )
        
      case 'experience':
        return (
          <div>
            <h2 className="text-2xl font-bold mb-4">Experience</h2>
            {portfolioData.experiences.map((exp, index) => (
              <div key={index} className="mb-4">
                <h3 className="font-semibold">{exp.title}</h3>
                <p>{exp.company}</p>
                <p>{exp.date}</p>
                <p>{exp.description}</p>
              </div>
            ))}
          </div>
        )
      case 'certificates':
        return (
          <div>
            <h2 className="text-2xl font-bold mb-4">Certificates</h2>
            {portfolioData.certificates.map((cert, index) => (
              <div key={index} className="mb-4 p-4 bg-gray-100 rounded-lg">
                <h3 className="font-semibold">{cert.name}</h3>
                <p>{cert.issuer} | {cert.date}</p>
                <Button onClick={() => downloadCertificate(cert.file)} className="mt-2 bg-green-500 hover:bg-green-600 text-white">
                  <Download className="mr-2 h-4 w-4" />
                  Download Certificate
                </Button>
              </div>
            ))}
          </div>
        )
      default:
        return null
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-100 to-gray-200 py-12 px-4 sm:px-6 lg:px-8">
      <Card className="max-w-6xl mx-auto bg-white shadow-xl rounded-lg overflow-hidden">
        <div className="md:flex">
          {/* Left side - Image */}
          <div className="md:w-1/3 bg-gradient-to-br from-blue-500 to-purple-600 p-8 flex items-center justify-center">
            <img
              src="/IMG_5116.JPG"
              alt="Ritik Kumar"
              className="rounded-full w-48 h-48 object-cover border-4 border-white shadow-lg"
            />
          </div>
          

         

          {/* Right side - Content */}
          <div className="md:w-2/3 p-8">
            {/* Navigation buttons */}
            <div className="flex flex-wrap gap-4 mb-6">
              {['about', 'resume', 'projects', 'experience', 'certificates'].map((page) => (
                <Button
                  key={page}
                  onClick={() => setActivePage(page)}
                  className={`${
                    activePage === page
                      ? 'bg-blue-600  text-white'
                      : 'bg-gray-200 text-gray-800 hover:bg-gray-300'
                  } transition-colors duration-200`}
                >
                  {page.charAt(0).toUpperCase() + page.slice(1)}
                </Button>
              ))}
            </div>

            {/* Name and title */}
            <h1 className="text-4xl font-bold text-gray-800 mb-2">{portfolioData.name}</h1>
            <p className="text-xl text-gray-600 mb-6">{portfolioData.title}</p>

            {/* Dynamic content based on active page */}
            <div className="mb-6">
              {renderContent()}
            </div>

            {/* MetaMask connection and donation */}
            <div className="mb-6">
              <Button onClick={connectWallet} className="mb-4 bg-orange-500 hover:bg-orange-600 text-white">
                <Wallet className="mr-2 h-4 w-4" />
                {walletAddress ? `Connected: ${walletAddress.slice(0, 6)}...${walletAddress.slice(-4)}` : "Connect MetaMask"}
              </Button>
              {walletAddress && (
                <div className="flex items-center">
                  <input
                    type="number"
                    value={donationAmount}
                    onChange={(e) => setDonationAmount(e.target.value)}
                    placeholder="ETH Amount"
                    className="border rounded p-2 mr-2"
                  />
                  <Button onClick={donateEther} className="bg-green-500 hover:bg-green-600 text-white">
                    Donate ETH
                  </Button>
                </div>
              )}
            </div>

            {/* Resume download button */}
            <Button onClick={downloadResume} className="mb-6 bg-blue-600 hover:bg-blue-700 text-white">
              <Download className="mr-2 h-4 w-4" />
              Download Resume
            </Button>

            {/* Social media icons */}
            <div className="flex space-x-4">
              <Link href="mailto:theritik43700@gmail.com" className="text-blue-600 hover:text-blue-800">
                <Mail className="w-6 h-6" />
              </Link>
              <Link href="tel:+917257077851" className="text-blue-600 hover:text-blue-800">
                <Phone className="w-6 h-6" />
              </Link>
              <Link href="https://github.com/heyritikk" className="text-blue-600 hover:text-blue-800">
                <Github className="w-6 h-6" />
              </Link>
              <Link href="https://www.linkedin.com/in/ritik-kumar13" className="text-blue-600 hover:text-blue-800">
                <Linkedin className="w-6 h-6" />

                
              </Link>
            </div>
          </div>
        </div>
      </Card>
    </div>
  )
}